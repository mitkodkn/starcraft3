#ifndef THREADS_H_
#define THREADS_H_

void *control(void*);
void *dig(void*);

#endif /* THREADS_H_ */
