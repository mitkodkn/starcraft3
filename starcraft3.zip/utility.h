#ifndef UTILITY_H_
#define UTILITY_H_

#include "types.h"

int initialize_map(map_t*, const int);
int initialize_center(command_center_t*);

#endif /* UTILITY_H_ */
