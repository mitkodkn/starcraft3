#ifndef CONTROLS_H_
#define CONTROLS_H_

#include "types.h"

void construct_marine(command_center_t*);
int train_scv(command_center_t*, map_t*);

#endif /* CONTROLS_H_ */
